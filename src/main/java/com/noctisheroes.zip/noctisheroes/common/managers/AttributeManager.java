package com.noctisheroes.common.managers;

import com.noctisheroes.common.ability.helpers.NoctisAbility;
import com.noctisheroes.entity.NoctisEntity;
import com.noctisheroes.entity.entities.viltrumite.base.ViltrumiteVariant;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;

import java.util.HashMap;
import java.util.Map;

public class AttributeManager<T extends NoctisEntity> {
    private final Map<String, NoctisAbility<T>> attributes = new HashMap<>();
    protected AttributeConfig config;

    public AttributeManager(AttributeConfig config) {
        this.config = config;
    }

    public static AttributeSupplier create(AttributeConfig config) {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, config.maxHealth)
                .add(Attributes.MOVEMENT_SPEED, config.movementSpeed)
                .add(Attributes.FLYING_SPEED, config.flyingSpeed)
                .add(Attributes.ATTACK_DAMAGE, config.attackDamage)
                .add(Attributes.ATTACK_KNOCKBACK, config.attackKnockback)
                .add(Attributes.ATTACK_SPEED, config.attackSpeed)
                .add(Attributes.FOLLOW_RANGE, config.followRange)
                .add(Attributes.ARMOR, config.armor)
                .add(Attributes.ARMOR_TOUGHNESS, config.armorToughness)
                .add(Attributes.KNOCKBACK_RESISTANCE, config.knockbackResistance)
                .build();
    }



    public static class AttributeConfig {
        public final double maxHealth;
        public final double movementSpeed;
        public final double flyingSpeed;
        public final double attackDamage;
        public final double attackKnockback;
        public final double attackSpeed;
        public final double followRange;
        public final double armor;
        public final double armorToughness;
        public final double knockbackResistance;


        private AttributeConfig(AttributeManager.AttributeConfig.Builder builder) {

            this.maxHealth = builder.maxHealth;
            this.movementSpeed = builder.movementSpeed;
            this.flyingSpeed = builder.flyingSpeed;
            this.attackDamage = builder.attackDamage;
            this.attackKnockback = builder.attackKnockback;
            this.attackSpeed = builder.attackSpeed;
            this.followRange = builder.followRange;
            this.armor = builder.armor;
            this.armorToughness = builder.armorToughness;
            this.knockbackResistance = builder.knockbackResistance;

        }

        public static class Builder {

            public double maxHealth = 100.0;
            public double movementSpeed = 0.3;
            public double flyingSpeed = 0.6;
            public double attackDamage = 5.0;
            public double attackKnockback = 0.5;
            public double attackSpeed = 0.3;
            public double followRange = 20.0;
            public double armor = 0.0;
            public double armorToughness = 0.0;
            public double knockbackResistance = 0.0;

            public AttributeManager.AttributeConfig.Builder maxHealth(double hp) {
                this.maxHealth = hp;
                return this;
            }

            public AttributeManager.AttributeConfig.Builder movementSpeed(double speed) {
                this.movementSpeed = speed;
                return this;
            }

            public AttributeManager.AttributeConfig.Builder flyingSpeed(double speed) {
                this.flyingSpeed = speed;
                return this;
            }

            public AttributeManager.AttributeConfig.Builder attackDamage(double damage) {
                this.attackDamage = damage;
                return this;
            }

            public AttributeManager.AttributeConfig.Builder attackKnockback(double kb) {
                this.attackKnockback = kb;
                return this;
            }

            public AttributeManager.AttributeConfig.Builder attackSpeed(double speed) {
                this.attackSpeed = speed;
                return this;
            }

            public AttributeManager.AttributeConfig.Builder followRange(double range) {
                this.followRange = range;
                return this;
            }

            public AttributeManager.AttributeConfig.Builder armor(double armor) {
                this.armor = armor;
                return this;
            }

            public AttributeManager.AttributeConfig.Builder armorToughness(double tough) {
                this.armorToughness = tough;
                return this;
            }

            public AttributeManager.AttributeConfig.Builder knockbackResistance(double resist) {
                this.knockbackResistance = resist;
                return this;
            }


            public AttributeManager.AttributeConfig build() {
                return new AttributeManager.AttributeConfig(this);
            }
        }
    }
}
